"""
app/core/database.py
Async SQLAlchemy engine + session factory + admin seeding.
"""
import logging
import os
from datetime import datetime, timezone

from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.orm import DeclarativeBase

from app.core.config import settings

logger = logging.getLogger(__name__)

if "sqlite" in settings.DATABASE_URL:
    db_file = settings.DATABASE_URL.split("///")[-1]
    db_abs_path = os.path.abspath(db_file)
    os.makedirs(os.path.dirname(db_abs_path) if os.path.dirname(db_abs_path) else ".", exist_ok=True)
    settings.DATABASE_URL = settings.DATABASE_URL.replace(db_file, db_abs_path)

connect_args = {"check_same_thread": False} if "sqlite" in settings.DATABASE_URL else {}

engine = create_async_engine(
    settings.DATABASE_URL,
    connect_args=connect_args,
    echo=False,
    pool_pre_ping=True,
)

AsyncSessionLocal = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)


class Base(DeclarativeBase):
    pass


async def get_db() -> AsyncSession:
    async with AsyncSessionLocal() as session:
        yield session


async def _seed_admin() -> None:
    from app.models.user import User
    from app.core.security import hash_password

    async with AsyncSessionLocal() as db:
        # Admin seeding must be idempotent across schema/data migrations.
        result = await db.execute(select(User).where(User.email == settings.ADMIN_EMAIL))
        existing = result.scalar_one_or_none()
        if existing:
            return

        admin = User(
            email=settings.ADMIN_EMAIL,
            hashed_password=hash_password(settings.ADMIN_PASSWORD),
            full_name=settings.ADMIN_FULL_NAME,
            is_active=True,
            is_admin=True,
        )
        db.add(admin)

        try:
            await db.commit()
        except Exception:
            # If the row was inserted concurrently or the DB still contains
            # a previous admin (unique constraint), swallow to keep startup alive.
            await db.rollback()
            logger.warning("Admin seed skipped (possible existing user) → %s", settings.ADMIN_EMAIL)
            return

        logger.info("✓ Admin account seeded → %s", settings.ADMIN_EMAIL)



async def _migrate_columns() -> None:
    """Add new columns to existing tables if they don't exist (SQLite ALTER TABLE)."""

    async with engine.begin() as conn:
        table_exists = await conn.execute(
            text("SELECT name FROM sqlite_master WHERE type='table' AND name='users'")
        )
        if table_exists.first() is None:
            return

        cols_result = await conn.execute(text("PRAGMA table_info(users)"))
        col_names = {row[1] for row in cols_result.fetchall()}

        new_user_cols = [
            ("telegram_bot_token", "VARCHAR(512)"),
            ("telegram_chat_id", "VARCHAR(64)"),
            ("failed_login_attempts", "INTEGER NOT NULL DEFAULT 0"),
            ("locked_until", "DATETIME"),
            ("reset_token", "VARCHAR(128)"),
            ("reset_token_expires", "DATETIME"),
        ]
        for col, col_type in new_user_cols:
            if col not in col_names:
                await conn.execute(text(f"ALTER TABLE users ADD COLUMN {col} {col_type}"))
                logger.info("Migrated: added users.%s", col)

        await _migrate_old_subscription_table(conn)


async def _migrate_old_subscription_table(conn) -> None:
    """Migrate old subscription_plans schema (period/amount_usdt) to new schema."""

    table_exists = await conn.execute(
        text("SELECT name FROM sqlite_master WHERE type='table' AND name='subscription_plans'")
    )
    if table_exists.first() is None:
        return

    cols_result = await conn.execute(text("PRAGMA table_info(subscription_plans)"))
    col_names = {row[1] for row in cols_result.fetchall()}

    # Old schema variants seen in the wild:
    # 1) period/amount_usdt columns exist, and plan_type doesn't → full rename/migration.
    # 2) period still exists alongside plan_type/duration_days but new inserts fail because
    #    some old column (period) is still NOT NULL.

    if "period" in col_names and "plan_type" not in col_names:
        # FULL MIGRATION (replace table definition)
        logger.info("Migrating old subscription_plans schema (period → plan_type/duration_days)")
        timestamp = datetime.now(timezone.utc).isoformat()
        await conn.execute(text("ALTER TABLE subscription_plans RENAME TO _old_subscription_plans"))
        await conn.execute(
            text(
                """
                CREATE TABLE subscription_plans (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name VARCHAR(64) NOT NULL,
                    plan_type VARCHAR(16) NOT NULL,
                    price_usdt NUMERIC(12, 2) NOT NULL DEFAULT 0,
                    duration_days INTEGER NOT NULL,
                    max_endpoints INTEGER DEFAULT 5,
                    max_submissions_per_day INTEGER DEFAULT 500,
                    features TEXT,
                    is_active BOOLEAN NOT NULL DEFAULT 1,
                    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
                )
                """
            )
        )
        await conn.execute(
            text(
                """
                INSERT INTO subscription_plans (
                    name, plan_type, price_usdt, duration_days,
                    max_endpoints, max_submissions_per_day,
                    is_active, created_at
                )
                SELECT
                    COALESCE(name, period) as name,
                    period as plan_type,
                    COALESCE(amount_usdt, 0) as price_usdt,
                    CASE period
                        WHEN 'free_trial' THEN 14
                        WHEN 'monthly' THEN 30
                        WHEN 'yearly' THEN 365
                        ELSE 30
                    END as duration_days,
                    5 as max_endpoints,
                    500 as max_submissions_per_day,
                    is_active,
                    COALESCE(created_at, :now)
                FROM _old_subscription_plans
                """
            ),
            {"now": timestamp},
        )
        await conn.execute(text("DROP TABLE _old_subscription_plans"))
        logger.info("Migrated subscription_plans from old schema to new schema")
        return

    # If period exists and the table definition still marks it NOT NULL, ensure it's never NULL
    # before any ORM inserts happen. This fixes partially-migrated DBs where earlier
    # inserts didn’t populate `period`.
    if "period" in col_names:
        logger.info("Ensuring subscription_plans.period is non-NULL (legacy compatibility)")

        # Backfill period based on whichever column we do have.
        # - Prefer plan_type if present.
        # - Fallback to duration_days if possible.
        # NOTE: some legacy schemas may not have plan_type/duration_days columns.
        set_clauses = [
            "WHEN plan_type = 'free_trial' THEN 'free_trial'",
            "WHEN plan_type = 'monthly' THEN 'monthly'",
            "WHEN plan_type = 'yearly' THEN 'yearly'",
            "WHEN duration_days = 14 THEN 'free_trial'",
            "WHEN duration_days = 30 THEN 'monthly'",
            "WHEN duration_days = 365 THEN 'yearly'",
        ]

        # Only reference plan_type/duration_days if those columns exist.
        if "plan_type" not in col_names:
            set_clauses = [c for c in set_clauses if "plan_type" not in c]
        if "duration_days" not in col_names:
            set_clauses = [c for c in set_clauses if "duration_days" not in c]

        # If we can't derive anything, fall back to a safe default.
        case_body = "\n                    ".join(set_clauses) if set_clauses else "WHEN 1=1 THEN 'monthly'"

        await conn.execute(
            text(
                f"""
                UPDATE subscription_plans
                SET period = CASE
                    {case_body}
                    ELSE period
                END
                WHERE period IS NULL
                """
            )
        )

    if "period" in col_names and "plan_type" in col_names:
        # BACKFILL variant: ensure period column has values for rows before seeding.
        # This prevents inserts that omit `period` from violating NOT NULL(period).
        logger.info("Backfilling subscription_plans.period / plan_type/duration_days")

        # Ensure plan_type & duration_days derived from period when missing.
        await conn.execute(
            text(
                """
                UPDATE subscription_plans
                SET
                    plan_type = COALESCE(plan_type, period),
                    duration_days = CASE
                        WHEN COALESCE(plan_type, period) = 'free_trial' THEN 14
                        WHEN COALESCE(plan_type, period) = 'monthly' THEN 30
                        WHEN COALESCE(plan_type, period) = 'yearly' THEN 365
                        ELSE duration_days
                    END,
                    price_usdt = COALESCE(price_usdt, amount_usdt)
                """
            )
        )

        # Ensure period itself isn't NULL for existing rows.
        await conn.execute(
            text(
                """
                UPDATE subscription_plans
                SET period = CASE
                    WHEN plan_type = 'free_trial' THEN 'free_trial'
                    WHEN plan_type = 'monthly' THEN 'monthly'
                    WHEN plan_type = 'yearly' THEN 'yearly'
                    ELSE period
                END
                WHERE period IS NULL
                """
            )
        )








async def _seed_subscription_plans() -> None:
    """Seed default subscription plans.

    This is resilient for existing DBs where earlier seeding/migrations might have
    partially inserted rows.
    """
    from app.models.subscription import SubscriptionPlan
    import json

    defaults = [
        SubscriptionPlan(
            name="Free Trial",
            plan_type="free_trial",
            price_usdt=0,
            duration_days=7,
            max_endpoints=3,
            max_submissions_per_day=100,
            features=json.dumps(
                [
                    "3 form endpoints",
                    "100 submissions/day",
                    "Email notifications",
                    "7-day access",
                ]
            ),
            is_active=True,
        ),
        SubscriptionPlan(
            name="Pro Monthly",
            plan_type="monthly",
            price_usdt=9.99,
            duration_days=30,
            max_endpoints=20,
            max_submissions_per_day=5000,
            features=json.dumps(
                [
                    "20 form endpoints",
                    "5,000 submissions/day",
                    "Email + Telegram notifications",
                    "Priority support",
                    "Custom redirects",
                ]
            ),
            is_active=True,
        ),
        SubscriptionPlan(
            name="Pro Yearly",
            plan_type="yearly",
            price_usdt=89.99,
            duration_days=365,
            max_endpoints=50,
            max_submissions_per_day=20000,
            features=json.dumps(
                [
                    "50 form endpoints",
                    "20,000 submissions/day",
                    "Email + Telegram notifications",
                    "Priority support",
                    "Custom redirects",
                    "2 months free vs monthly",
                ]
            ),
            is_active=True,
        ),
    ]

    async with AsyncSessionLocal() as db:
        existing = await db.execute(
            select(SubscriptionPlan.plan_type).where(SubscriptionPlan.plan_type.in_([d.plan_type for d in defaults]))
        )
        existing_plan_types = {row[0] for row in existing.all()}

        to_insert = [d for d in defaults if d.plan_type not in existing_plan_types]
        if not to_insert:
            return

        db.add_all(to_insert)
        await db.commit()
        logger.info("✓ Seeded %s subscription plan(s)", len(to_insert))


async def init_db() -> None:
    """Create all tables, run migrations, then seed admin."""
    async with engine.begin() as conn:
        from app.models import user, endpoint, submission  # noqa: F401
        from app.models import chat  # noqa: F401
        from app.models import subscription  # noqa: F401
        await conn.run_sync(Base.metadata.create_all)

    await _migrate_columns()
    await _seed_admin()
    await _seed_subscription_plans()


async def _migrate_subscription_columns() -> None:
    """Add subscription tables if missing (for existing DBs)."""
    async with engine.begin() as conn:
        # Tables are created by create_all; this is a no-op safety check
        pass
