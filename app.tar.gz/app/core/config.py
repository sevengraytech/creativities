"""
app/core/config.py
Centralised settings loaded from environment / .env file.
"""
from typing import List
from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # ── App ──────────────────────────────────────────────────────────
    SECRET_KEY: str = "dev-secret-change-me"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 10080  # 7 days
    ENVIRONMENT: str = "development"          # development | production

    # ── Admin bootstrap ──────────────────────────────────────────────
    ADMIN_EMAIL: str = "admin@formrelay.local"
    ADMIN_PASSWORD: str = "Admin@Relay2025!"
    ADMIN_FULL_NAME: str = "FormRelay Admin"
    ADMIN_SECRET_TOKEN: str = "change-me"     # guards /api/admin/* routes

    # ── Database ─────────────────────────────────────────────────────
    DATABASE_URL: str = "sqlite+aiosqlite:///./data/formrelay.db"

    # ── Email ────────────────────────────────────────────────────────
    SMTP_HOST: str = "smtp.gmail.com"
    SMTP_PORT: int = 587
    SMTP_USERNAME: str = ""
    SMTP_PASSWORD: str = ""
    SMTP_FROM_EMAIL: str = ""
    SMTP_FROM_NAME: str = "FormRelay"

    # ── CORS ─────────────────────────────────────────────────────────
    CORS_ORIGINS: str = "*"                   # comma-separated list or "*"

    # ── Telegram forwarding ─────────────────────────────────────────────
    # IMPORTANT: as requested, the account is created by the server user via app.
    # Telegram token/chat_id must be provided by the account's user profile.
    # We store these fields on the User model, but config keeps no defaults.

    # ── Frontend base URL ─────────────────────────────────────────────
    BASE_URL: str = "http://localhost:8000"


    @property
    def cors_origins_list(self) -> List[str]:
        if self.CORS_ORIGINS.strip() == "*":
            return ["*"]
        return [o.strip() for o in self.CORS_ORIGINS.split(",") if o.strip()]

    @property
    def is_production(self) -> bool:
        return self.ENVIRONMENT.lower() == "production"


settings = Settings()
