"""
app/core/email.py
Async email delivery via SMTP (works with Gmail, Mailgun SMTP, SendGrid SMTP, etc.)
"""
import json
import logging
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

import aiosmtplib

from app.core.config import settings

logger = logging.getLogger(__name__)


def _build_submission_html(endpoint_name: str, fields: dict, submitted_at: datetime) -> str:
    """Render a clean HTML email for a form submission."""
    rows = "".join(
        f"""
        <tr>
          <td style="padding:8px 12px;font-weight:600;color:#374151;background:#f9fafb;
                     border:1px solid #e5e7eb;width:35%;vertical-align:top">{key}</td>
          <td style="padding:8px 12px;color:#111827;border:1px solid #e5e7eb;word-break:break-word">{value}</td>
        </tr>"""
        for key, value in fields.items()
    )
    return f"""
<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;font-family:'Segoe UI',Arial,sans-serif;background:#f0f4f8">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f0f4f8;padding:32px 0">
    <tr><td align="center">
      <table width="600" cellpadding="0" cellspacing="0"
             style="background:#fff;border-radius:12px;overflow:hidden;
                    box-shadow:0 2px 12px rgba(0,0,0,.08)">
        <!-- Header -->
        <tr>
          <td style="background:linear-gradient(135deg,#0ea5e9,#6366f1);padding:28px 32px">
            <div style="color:#fff;font-size:11px;font-weight:700;letter-spacing:2px;
                        text-transform:uppercase;margin-bottom:6px">FormRelay</div>
            <div style="color:#fff;font-size:22px;font-weight:700">New Submission</div>
            <div style="color:rgba(255,255,255,.8);font-size:14px;margin-top:4px">{endpoint_name}</div>
          </td>
        </tr>
        <!-- Body -->
        <tr>
          <td style="padding:28px 32px">
            <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse">
              {rows}
            </table>
          </td>
        </tr>
        <!-- Footer -->
        <tr>
          <td style="padding:16px 32px 24px;border-top:1px solid #e5e7eb">
            <p style="margin:0;color:#9ca3af;font-size:12px">
              Submitted on {submitted_at.strftime("%B %d, %Y at %H:%M UTC")} · Delivered by FormRelay
            </p>
          </td>
        </tr>
      </table>
    </td></tr>
  </table>
</body>
</html>"""


def _build_submission_text(endpoint_name: str, fields: dict, submitted_at: datetime) -> str:
    lines = [f"New FormRelay submission for: {endpoint_name}", "=" * 50, ""]
    for k, v in fields.items():
        lines.append(f"{k}: {v}")
    lines += ["", f"Submitted: {submitted_at.strftime('%Y-%m-%d %H:%M UTC')}"]
    return "\n".join(lines)


async def send_submission_email(
    to_email: str,
    endpoint_name: str,
    fields: dict,
    submitted_at: datetime,
) -> bool:
    """
    Send a form-submission notification email.
    Returns True on success, False on failure.
    """
    if not settings.SMTP_USERNAME:
        logger.warning("SMTP not configured – skipping email delivery")
        return False

    msg = MIMEMultipart("alternative")
    msg["Subject"] = f"[FormRelay] New submission: {endpoint_name}"
    msg["From"] = f"{settings.SMTP_FROM_NAME} <{settings.SMTP_FROM_EMAIL}>"
    msg["To"] = to_email

    msg.attach(MIMEText(_build_submission_text(endpoint_name, fields, submitted_at), "plain"))
    msg.attach(MIMEText(_build_submission_html(endpoint_name, fields, submitted_at), "html"))

    try:
        await aiosmtplib.send(
            msg,
            hostname=settings.SMTP_HOST,
            port=settings.SMTP_PORT,
            username=settings.SMTP_USERNAME,
            password=settings.SMTP_PASSWORD,
            start_tls=True,
            timeout=15,
        )
        logger.info("Email sent to %s for endpoint '%s'", to_email, endpoint_name)
        return True
    except Exception as exc:
        logger.error("Failed to send email to %s: %s", to_email, exc)
        return False
