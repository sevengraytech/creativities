"""
app/core/subscription_guard.py

Shared helpers that enforce the free-trial/subscription gate:
  - Users may not CREATE endpoints without an active subscription (trial or paid).
  - Endpoints stop RECEIVING payloads once their owner's subscription has expired.
"""
from datetime import datetime, timezone

from fastapi import Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.deps import get_current_user
from app.models.subscription import UserSubscription
from app.models.user import User


async def get_active_subscription(user_id: int, db: AsyncSession) -> UserSubscription | None:
    """Return the user's UserSubscription row if it exists and is currently active/unexpired."""
    result = await db.execute(
        select(UserSubscription).where(UserSubscription.user_id == user_id)
    )
    sub = result.scalar_one_or_none()
    if not sub:
        return None

    now = datetime.now(timezone.utc)
    expires_at = sub.expires_at
    if expires_at is not None and getattr(expires_at, "tzinfo", None) is None:
        expires_at = expires_at.replace(tzinfo=timezone.utc)

    if not sub.is_active or expires_at is None or expires_at <= now:
        # Lazily flip the flag so admin views stay accurate.
        if sub.is_active:
            sub.is_active = False
            await db.commit()
        return None

    return sub


SUBSCRIPTION_REQUIRED_DETAIL = (
    "Your free trial or subscription has ended. Please subscribe to continue "
    "creating endpoints and receiving form submissions."
)


async def require_active_subscription(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> UserSubscription:
    """FastAPI dependency: blocks the request unless the current user has an active subscription."""
    sub = await get_active_subscription(current_user.id, db)
    if sub is None:
        raise HTTPException(
            status_code=status.HTTP_402_PAYMENT_REQUIRED,
            detail=SUBSCRIPTION_REQUIRED_DETAIL,
        )
    return sub
