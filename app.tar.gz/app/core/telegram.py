"""app/core/telegram.py

Telegram Bot API delivery (async).

Used to forward received form submission fields to a Telegram chat.
"""
from __future__ import annotations

import logging
from datetime import datetime
from typing import Any

import httpx

logger = logging.getLogger(__name__)


def _format_fields(fields: dict[str, Any]) -> str:
    # Keep message readable; Telegram supports Markdown/HTML but we'll use plain text.
    # Format: key: value per line.
    lines: list[str] = []
    for k, v in fields.items():
        # Ensure single-line values
        val = str(v).replace("\r\n", " ").replace("\n", " ")
        lines.append(f"{k}: {val}")
    return "\n".join(lines)


async def send_submission_telegram(
    *,
    bot_token: str,
    chat_id: str,
    endpoint_name: str,
    fields: dict[str, Any],
    submitted_at: datetime,
) -> bool:
    """Send submission details to Telegram.

    Returns True on success, False on failure.
    """
    if not bot_token or not chat_id:
        logger.warning("Telegram not configured – skipping telegram delivery")
        return False

    text = (
        f"🆕 New FormRelay submission\n"
        f"Endpoint: {endpoint_name}\n"
        f"Submitted: {submitted_at.strftime('%Y-%m-%d %H:%M UTC')}\n\n"
        f"{_format_fields(fields)}"
    )

    # Telegram message limit is 4096 chars for many bots.
    if len(text) > 3800:
        text = text[:3750] + "…"

    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"

    try:
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.post(
                url,
                data={
                    "chat_id": chat_id,
                    "text": text,
                },
            )
            if resp.status_code != 200:
                logger.error("Telegram send failed: status=%s body=%s", resp.status_code, resp.text)
                return False

            payload = resp.json()
            if not payload.get("ok"):
                logger.error("Telegram send failed: payload=%s", payload)
                return False

        logger.info("Telegram sent to chat_id=%s for endpoint '%s'", chat_id, endpoint_name)
        return True
    except Exception as exc:
        logger.error("Telegram send exception: %s", exc)
        return False

