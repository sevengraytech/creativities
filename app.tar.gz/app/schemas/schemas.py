"""
app/schemas/schemas.py
Pydantic v2 request/response models.
"""
from datetime import datetime
from typing import Optional

from pydantic import BaseModel, EmailStr, Field


# ── Auth ──────────────────────────────────────────────────────────────────────

class UserRegister(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)
    full_name: Optional[str] = None
    telegram_bot_token: Optional[str] = None
    telegram_chat_id: Optional[str] = None


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserOut(BaseModel):
    id: int
    email: str
    full_name: Optional[str]
    is_admin: bool = False
    is_active: bool = True
    created_at: datetime

    model_config = {"from_attributes": True}


# ── Password Reset ────────────────────────────────────────────────────────────

class PasswordResetRequest(BaseModel):
    email: EmailStr


class PasswordResetConfirm(BaseModel):
    token: str
    new_password: str = Field(min_length=8, max_length=128)


# ── Telegram settings ───────────────────────────────────────────────────────

class TelegramSettingsIn(BaseModel):
    telegram_bot_token: Optional[str] = None
    telegram_chat_id: Optional[str] = None


class TelegramSettingsOut(BaseModel):
    telegram_bot_token: Optional[str] = None
    telegram_chat_id: Optional[str] = None


class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


# ── Endpoints ─────────────────────────────────────────────────────────────────

class EndpointCreate(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    description: Optional[str] = None
    redirect_url: Optional[str] = None
    email_subject: Optional[str] = None


class EndpointUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    description: Optional[str] = None
    redirect_url: Optional[str] = None
    email_subject: Optional[str] = None
    is_active: Optional[bool] = None


class EndpointOut(BaseModel):
    id: int
    token: str
    name: str
    description: Optional[str]
    redirect_url: Optional[str]
    email_subject: Optional[str]
    is_active: bool
    created_at: datetime
    submission_count: int = 0

    model_config = {"from_attributes": True}


# ── Submissions ───────────────────────────────────────────────────────────────

class SubmissionOut(BaseModel):
    id: int
    endpoint_id: int
    fields_json: str
    sender_ip: Optional[str]
    status: str
    submitted_at: datetime

    model_config = {"from_attributes": True}


# ── Generic ───────────────────────────────────────────────────────────────────

class MessageOut(BaseModel):
    message: str


# ── Subscription Plans ────────────────────────────────────────────────────────

class PlanOut(BaseModel):
    id: int
    name: str
    plan_type: str
    price_usdt: float
    duration_days: int
    max_endpoints: int
    max_submissions_per_day: int
    features: Optional[str] = None
    is_active: bool
    model_config = {"from_attributes": True}

class PlanCreate(BaseModel):
    name: str = Field(min_length=1, max_length=64)
    plan_type: str = Field(pattern="^(free_trial|monthly|yearly)$")
    price_usdt: float = Field(ge=0)
    duration_days: int = Field(ge=1)
    max_endpoints: int = Field(ge=1, default=5)
    max_submissions_per_day: int = Field(ge=1, default=500)
    features: Optional[str] = None   # JSON string

class PlanUpdate(BaseModel):
    name: Optional[str] = None
    price_usdt: Optional[float] = None
    duration_days: Optional[int] = None
    max_endpoints: Optional[int] = None
    max_submissions_per_day: Optional[int] = None
    features: Optional[str] = None
    is_active: Optional[bool] = None


# ── USDT Wallets ──────────────────────────────────────────────────────────────

class WalletOut(BaseModel):
    id: int
    label: str
    network: str
    address: str
    is_active: bool
    model_config = {"from_attributes": True}

class WalletCreate(BaseModel):
    label: str = Field(min_length=1, max_length=64)
    network: str = Field(min_length=1, max_length=32)
    address: str = Field(min_length=10, max_length=256)

class WalletUpdate(BaseModel):
    label: Optional[str] = None
    network: Optional[str] = None
    address: Optional[str] = None
    is_active: Optional[bool] = None


# ── Payments ──────────────────────────────────────────────────────────────────

class PaymentSubmit(BaseModel):
    plan_id: int
    wallet_id: int
    tx_hash: str = Field(min_length=10, max_length=256)

class PaymentOut(BaseModel):
    id: int
    user_id: int
    plan_id: int
    wallet_id: Optional[int]
    amount_usdt: float
    tx_hash: Optional[str]
    status: str
    admin_note: Optional[str]
    submitted_at: datetime
    reviewed_at: Optional[datetime]
    model_config = {"from_attributes": True}

class PaymentReview(BaseModel):
    action: str = Field(pattern="^(approve|reject)$")
    admin_note: Optional[str] = None


class SubscriptionAssign(BaseModel):
    plan_id: int = Field(gt=0)


# ── User Subscription ─────────────────────────────────────────────────────────

class SubscriptionOut(BaseModel):
    id: int
    user_id: int
    plan_id: int
    started_at: datetime
    expires_at: datetime
    is_active: bool
    model_config = {"from_attributes": True}
