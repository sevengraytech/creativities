"""
app/routers/admin_subscriptions.py
Admin endpoints for managing plans, wallets, and payment approvals.
All routes require X-Admin-Token header.
"""
import json
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, Header, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.database import get_db
from app.models.subscription import SubscriptionPayment, SubscriptionPlan, UserSubscription, UsdtWallet
from app.models.user import User
from app.schemas.schemas import (
    MessageOut, PaymentReview, PlanCreate, PlanOut, PlanUpdate,
    WalletCreate, WalletOut, WalletUpdate, SubscriptionAssign,
)

router = APIRouter(prefix="/api/admin/subscriptions", tags=["admin-subscriptions"])


async def require_admin_token(x_admin_token: str = Header(...)):
    if x_admin_token != settings.ADMIN_SECRET_TOKEN:
        raise HTTPException(status_code=403, detail="Invalid admin token")


# ── Plans CRUD ────────────────────────────────────────────────────────────────

@router.get("/plans", response_model=list[PlanOut], dependencies=[Depends(require_admin_token)])
async def admin_list_plans(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(SubscriptionPlan).order_by(SubscriptionPlan.id))
    return result.scalars().all()


@router.post("/plans", response_model=PlanOut, dependencies=[Depends(require_admin_token)])
async def admin_create_plan(payload: PlanCreate, db: AsyncSession = Depends(get_db)):
    plan = SubscriptionPlan(**payload.model_dump())
    db.add(plan)
    await db.commit()
    await db.refresh(plan)
    return plan


@router.patch("/plans/{plan_id}", response_model=PlanOut, dependencies=[Depends(require_admin_token)])
async def admin_update_plan(plan_id: int, payload: PlanUpdate, db: AsyncSession = Depends(get_db)):
    res = await db.execute(select(SubscriptionPlan).where(SubscriptionPlan.id == plan_id))
    plan = res.scalar_one_or_none()
    if not plan:
        raise HTTPException(status_code=404, detail="Plan not found")
    for k, v in payload.model_dump(exclude_none=True).items():
        setattr(plan, k, v)
    await db.commit()
    await db.refresh(plan)
    return plan


@router.delete("/plans/{plan_id}", response_model=MessageOut, dependencies=[Depends(require_admin_token)])
async def admin_delete_plan(plan_id: int, db: AsyncSession = Depends(get_db)):
    res = await db.execute(select(SubscriptionPlan).where(SubscriptionPlan.id == plan_id))
    plan = res.scalar_one_or_none()
    if not plan:
        raise HTTPException(status_code=404, detail="Plan not found")
    await db.delete(plan)
    await db.commit()
    return MessageOut(message="Plan deleted")


# ── Wallets CRUD ──────────────────────────────────────────────────────────────

@router.get("/wallets", response_model=list[WalletOut], dependencies=[Depends(require_admin_token)])
async def admin_list_wallets(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(UsdtWallet).order_by(UsdtWallet.id))
    return result.scalars().all()


@router.post("/wallets", response_model=WalletOut, dependencies=[Depends(require_admin_token)])
async def admin_create_wallet(payload: WalletCreate, db: AsyncSession = Depends(get_db)):
    wallet = UsdtWallet(**payload.model_dump())
    db.add(wallet)
    await db.commit()
    await db.refresh(wallet)
    return wallet


@router.patch("/wallets/{wallet_id}", response_model=WalletOut, dependencies=[Depends(require_admin_token)])
async def admin_update_wallet(wallet_id: int, payload: WalletUpdate, db: AsyncSession = Depends(get_db)):
    res = await db.execute(select(UsdtWallet).where(UsdtWallet.id == wallet_id))
    wallet = res.scalar_one_or_none()
    if not wallet:
        raise HTTPException(status_code=404, detail="Wallet not found")
    for k, v in payload.model_dump(exclude_none=True).items():
        setattr(wallet, k, v)
    await db.commit()
    await db.refresh(wallet)
    return wallet


@router.delete("/wallets/{wallet_id}", response_model=MessageOut, dependencies=[Depends(require_admin_token)])
async def admin_delete_wallet(wallet_id: int, db: AsyncSession = Depends(get_db)):
    res = await db.execute(select(UsdtWallet).where(UsdtWallet.id == wallet_id))
    wallet = res.scalar_one_or_none()
    if not wallet:
        raise HTTPException(status_code=404, detail="Wallet not found")
    await db.delete(wallet)
    await db.commit()
    return MessageOut(message="Wallet deleted")


# ── Payments: list & review ───────────────────────────────────────────────────

@router.get("/payments", dependencies=[Depends(require_admin_token)])
async def admin_list_payments(db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(SubscriptionPayment).order_by(SubscriptionPayment.submitted_at.desc()).limit(200)
    )
    payments = result.scalars().all()
    out = []
    for p in payments:
        user_res = await db.execute(select(User).where(User.id == p.user_id))
        user = user_res.scalar_one_or_none()
        plan_res = await db.execute(select(SubscriptionPlan).where(SubscriptionPlan.id == p.plan_id))
        plan = plan_res.scalar_one_or_none()
        wallet_res = await db.execute(select(UsdtWallet).where(UsdtWallet.id == p.wallet_id)) if p.wallet_id else None
        wallet = wallet_res.scalar_one_or_none() if wallet_res else None
        out.append({
            "id": p.id,
            "user_id": p.user_id,
            "user_email": user.email if user else "—",
            "plan_id": p.plan_id,
            "plan_name": plan.name if plan else "—",
            "wallet_id": p.wallet_id,
            "wallet_network": wallet.network if wallet else "—",
            "wallet_address": wallet.address if wallet else "—",
            "amount_usdt": float(p.amount_usdt),
            "tx_hash": p.tx_hash,
            "status": p.status,
            "admin_note": p.admin_note,
            "submitted_at": p.submitted_at.isoformat(),
            "reviewed_at": p.reviewed_at.isoformat() if p.reviewed_at else None,
        })
    return out


@router.post("/payments/{payment_id}/review", response_model=MessageOut, dependencies=[Depends(require_admin_token)])
async def admin_review_payment(
    payment_id: int,
    payload: PaymentReview,
    db: AsyncSession = Depends(get_db),
):
    res = await db.execute(select(SubscriptionPayment).where(SubscriptionPayment.id == payment_id))
    payment = res.scalar_one_or_none()
    if not payment:
        raise HTTPException(status_code=404, detail="Payment not found")
    if payment.status != "pending":
        raise HTTPException(status_code=400, detail=f"Payment already {payment.status}")

    now = datetime.now(timezone.utc).replace(tzinfo=None)
    payment.reviewed_at = now
    payment.admin_note = payload.admin_note

    if payload.action == "approve":
        payment.status = "approved"

        # Get plan for duration
        plan_res = await db.execute(select(SubscriptionPlan).where(SubscriptionPlan.id == payment.plan_id))
        plan = plan_res.scalar_one_or_none()
        if not plan:
            raise HTTPException(status_code=400, detail="Plan no longer exists")

        # Upsert user subscription (extend if existing)
        sub_res = await db.execute(
            select(UserSubscription).where(UserSubscription.user_id == payment.user_id)
        )
        sub = sub_res.scalar_one_or_none()
        if sub:
            # Extend from current expiry if still active, else from now
            base = max(sub.expires_at, now)
            sub.expires_at = base + timedelta(days=plan.duration_days)
            sub.plan_id = plan.id
            sub.payment_id = payment.id
            sub.is_active = True
        else:
            sub = UserSubscription(
                user_id=payment.user_id,
                plan_id=plan.id,
                payment_id=payment.id,
                started_at=now,
                expires_at=now + timedelta(days=plan.duration_days),
                is_active=True,
            )
            db.add(sub)

        await db.commit()
        return MessageOut(message=f"Payment approved. Subscription extended by {plan.duration_days} days.")

    else:  # reject
        payment.status = "rejected"
        await db.commit()
        return MessageOut(message="Payment rejected.")


# ── Subscriptions: list all ───────────────────────────────────────────────────

@router.get("/subscriptions", dependencies=[Depends(require_admin_token)])
async def admin_list_subscriptions(db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(UserSubscription).order_by(UserSubscription.expires_at.desc())
    )
    subs = result.scalars().all()
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    out = []
    for s in subs:
        user_res = await db.execute(select(User).where(User.id == s.user_id))
        user = user_res.scalar_one_or_none()
        plan_res = await db.execute(select(SubscriptionPlan).where(SubscriptionPlan.id == s.plan_id))
        plan = plan_res.scalar_one_or_none()
        out.append({
            "id": s.id,
            "user_id": s.user_id,
            "user_email": user.email if user else "—",
            "plan_name": plan.name if plan else "—",
            "plan_type": plan.plan_type if plan else "—",
            "started_at": s.started_at.isoformat(),
            "expires_at": s.expires_at.isoformat(),
            "days_left": max(0, (s.expires_at - now).days),
            "status": "active" if s.is_active and s.expires_at > now else "expired",
        })
    return out


# ── User Subscription Update ─────────────────────────────────────────────────

@router.post("/{user_id}/assign", response_model=MessageOut, dependencies=[Depends(require_admin_token)])
async def admin_assign_subscription(
    user_id: int,
    payload: SubscriptionAssign,
    db: AsyncSession = Depends(get_db),
):
    """Admin assigns a subscription plan to a user."""
    plan_id = payload.plan_id
    user_res = await db.execute(select(User).where(User.id == user_id))
    user = user_res.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    plan_res = await db.execute(select(SubscriptionPlan).where(SubscriptionPlan.id == plan_id))
    plan = plan_res.scalar_one_or_none()
    if not plan:
        raise HTTPException(status_code=404, detail="Plan not found")

    now = datetime.now(timezone.utc).replace(tzinfo=None)
    sub_res = await db.execute(select(UserSubscription).where(UserSubscription.user_id == user_id))
    sub = sub_res.scalar_one_or_none()

    if sub:
        sub.plan_id = plan.id
        sub.expires_at = max(sub.expires_at, now) + timedelta(days=plan.duration_days)
        sub.is_active = True
    else:
        sub = UserSubscription(
            user_id=user_id,
            plan_id=plan.id,
            started_at=now,
            expires_at=now + timedelta(days=plan.duration_days),
            is_active=True,
        )
        db.add(sub)

    await db.commit()
    return MessageOut(message=f"Subscription assigned: {plan.name} for {plan.duration_days} days")


@router.delete("/{user_id}", response_model=MessageOut, dependencies=[Depends(require_admin_token)])
async def admin_remove_subscription(user_id: int, db: AsyncSession = Depends(get_db)):
    """Admin removes a user's subscription."""
    sub_res = await db.execute(select(UserSubscription).where(UserSubscription.user_id == user_id))
    sub = sub_res.scalar_one_or_none()
    if not sub:
        raise HTTPException(status_code=404, detail="No subscription found for this user")
    await db.delete(sub)
    await db.commit()
    return MessageOut(message="Subscription removed")


# ── Stats summary ─────────────────────────────────────────────────────────────

@router.get("/stats", dependencies=[Depends(require_admin_token)])
async def admin_sub_stats(db: AsyncSession = Depends(get_db)):
    from sqlalchemy import func
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    total_subs = (await db.execute(select(func.count()).select_from(UserSubscription))).scalar()
    active_subs = (await db.execute(
        select(func.count()).select_from(UserSubscription)
        .where(UserSubscription.is_active == True, UserSubscription.expires_at > now)
    )).scalar()
    pending_payments = (await db.execute(
        select(func.count()).select_from(SubscriptionPayment)
        .where(SubscriptionPayment.status == "pending")
    )).scalar()
    total_revenue = (await db.execute(
        select(func.sum(SubscriptionPayment.amount_usdt))
        .where(SubscriptionPayment.status == "approved")
    )).scalar() or 0

    return {
        "total_subscriptions": total_subs,
        "active_subscriptions": active_subs,
        "pending_payments": pending_payments,
        "total_revenue_usdt": float(total_revenue),
    }
