"""
app/routers/chat.py
Live chat between users and admin via WebSocket + REST fallback.
"""
import json
import logging
from datetime import datetime, timezone
from typing import Dict, Set

from fastapi import APIRouter, Depends, Header, HTTPException, WebSocket, WebSocketDisconnect, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.database import get_db
from app.core.deps import get_current_user
from app.models.chat import ChatMessage
from app.models.user import User
from app.schemas.schemas import MessageOut

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/chat", tags=["chat"])

# ── Connection Manager ────────────────────────────────────────────────────────

class ConnectionManager:
    def __init__(self):
        # user_id -> set of user WebSockets
        self.user_connections: Dict[int, Set[WebSocket]] = {}
        # admin WebSockets
        self.admin_connections: Set[WebSocket] = set()

    async def connect_user(self, user_id: int, ws: WebSocket):
        await ws.accept()
        self.user_connections.setdefault(user_id, set()).add(ws)
        logger.info("User %d connected to chat", user_id)

    async def connect_admin(self, ws: WebSocket):
        await ws.accept()
        self.admin_connections.add(ws)
        logger.info("Admin connected to chat")

    def disconnect_user(self, user_id: int, ws: WebSocket):
        conns = self.user_connections.get(user_id, set())
        conns.discard(ws)
        if not conns:
            self.user_connections.pop(user_id, None)

    def disconnect_admin(self, ws: WebSocket):
        self.admin_connections.discard(ws)

    async def send_to_user(self, user_id: int, payload: dict):
        for ws in list(self.user_connections.get(user_id, set())):
            try:
                await ws.send_json(payload)
            except Exception:
                self.user_connections.get(user_id, set()).discard(ws)

    async def broadcast_to_admins(self, payload: dict):
        for ws in list(self.admin_connections):
            try:
                await ws.send_json(payload)
            except Exception:
                self.admin_connections.discard(ws)

    def online_users(self) -> list[int]:
        return list(self.user_connections.keys())


manager = ConnectionManager()


# ── Helper ───────────────────────────────────────────────────────────────────

async def require_admin_token(x_admin_token: str = Header(...)):
    if x_admin_token != settings.ADMIN_SECRET_TOKEN:
        raise HTTPException(status_code=403, detail="Invalid admin token")


def _msg_dict(msg: ChatMessage) -> dict:
    return {
        "id": msg.id,
        "user_id": msg.user_id,
        "sender": msg.sender,
        "message": msg.message,
        "is_read": msg.is_read,
        "created_at": msg.created_at.isoformat(),
    }


# ── User WebSocket ────────────────────────────────────────────────────────────

@router.websocket("/ws/user")
async def user_chat_ws(websocket: WebSocket, db: AsyncSession = Depends(get_db)):
    """WebSocket for authenticated users. Auth via cookie token."""
    from app.core.security import decode_access_token
    token = websocket.cookies.get("access_token")
    if not token:
        await websocket.close(code=4001)
        return

    user_id_str = decode_access_token(token)
    if not user_id_str:
        await websocket.close(code=4001)
        return

    result = await db.execute(select(User).where(User.id == int(user_id_str)))
    user = result.scalar_one_or_none()
    if not user or not user.is_active:
        await websocket.close(code=4003)
        return

    await manager.connect_user(user.id, websocket)

    # Send last 50 messages for this user on connect
    history = await db.execute(
        select(ChatMessage)
        .where(ChatMessage.user_id == user.id)
        .order_by(ChatMessage.created_at.asc())
        .limit(50)
    )
    messages = history.scalars().all()
    await websocket.send_json({"type": "history", "messages": [_msg_dict(m) for m in messages]})

    try:
        while True:
            raw = await websocket.receive_text()
            data = json.loads(raw)
            text = (data.get("message") or "").strip()
            if not text:
                continue

            msg = ChatMessage(user_id=user.id, sender="user", message=text)
            db.add(msg)
            await db.commit()
            await db.refresh(msg)

            payload = {"type": "message", **_msg_dict(msg), "user_email": user.email}
            # echo back to user
            await manager.send_to_user(user.id, {"type": "message", **_msg_dict(msg)})
            # notify all admins
            await manager.broadcast_to_admins(payload)

    except WebSocketDisconnect:
        manager.disconnect_user(user.id, websocket)
    except Exception as e:
        logger.error("User WS error: %s", e)
        manager.disconnect_user(user.id, websocket)


# ── Admin WebSocket ───────────────────────────────────────────────────────────

@router.websocket("/ws/admin")
async def admin_chat_ws(websocket: WebSocket, db: AsyncSession = Depends(get_db)):
    """WebSocket for admin. Auth via ?token= query param (admin secret)."""
    token = websocket.query_params.get("token")
    if token != settings.ADMIN_SECRET_TOKEN:
        await websocket.close(code=4003)
        return

    await manager.connect_admin(websocket)

    # Send all recent messages grouped by user (last 100)
    history = await db.execute(
        select(ChatMessage).order_by(ChatMessage.created_at.asc()).limit(100)
    )
    messages = history.scalars().all()
    await websocket.send_json({"type": "history", "messages": [_msg_dict(m) for m in messages]})

    # Send current online users
    await websocket.send_json({"type": "online_users", "user_ids": manager.online_users()})

    try:
        while True:
            raw = await websocket.receive_text()
            data = json.loads(raw)
            text = (data.get("message") or "").strip()
            target_user_id = data.get("user_id")
            if not text or not target_user_id:
                continue

            msg = ChatMessage(user_id=int(target_user_id), sender="admin", message=text)
            db.add(msg)
            await db.commit()
            await db.refresh(msg)

            # Send to that specific user
            await manager.send_to_user(int(target_user_id), {"type": "message", **_msg_dict(msg)})
            # Echo back to all admins
            await manager.broadcast_to_admins({"type": "message", **_msg_dict(msg)})

    except WebSocketDisconnect:
        manager.disconnect_admin(websocket)
    except Exception as e:
        logger.error("Admin WS error: %s", e)
        manager.disconnect_admin(websocket)


# ── REST endpoints ────────────────────────────────────────────────────────────

@router.get("/history", summary="Get own chat history")
async def get_my_chat(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(ChatMessage)
        .where(ChatMessage.user_id == current_user.id)
        .order_by(ChatMessage.created_at.asc())
        .limit(100)
    )
    return [_msg_dict(m) for m in result.scalars().all()]


@router.get("/admin/users", dependencies=[Depends(require_admin_token)])
async def admin_list_chat_users(db: AsyncSession = Depends(get_db)):
    """Return users who have sent at least one chat message, with unread counts."""
    from sqlalchemy import func, distinct
    subq = (
        select(
            ChatMessage.user_id,
            func.count(ChatMessage.id).label("total"),
            func.sum(
                (ChatMessage.is_read == False).cast(Integer) if False else  # noqa
                func.cast((ChatMessage.sender == "user") & (ChatMessage.is_read == False), Integer)
            ).label("unread"),
        )
        .group_by(ChatMessage.user_id)
        .subquery()
    )
    rows = await db.execute(
        select(User.id, User.email, User.full_name)
        .join(subq, User.id == subq.c.user_id)
    )
    users = rows.fetchall()

    # Get unread counts manually (simpler)
    result = []
    for u in users:
        unread_res = await db.execute(
            select(func.count()).select_from(ChatMessage).where(
                ChatMessage.user_id == u.id,
                ChatMessage.sender == "user",
                ChatMessage.is_read == False,  # noqa
            )
        )
        unread = unread_res.scalar() or 0
        result.append({
            "user_id": u.id,
            "email": u.email,
            "full_name": u.full_name,
            "unread": unread,
            "online": u.id in manager.online_users(),
        })
    return result


@router.get("/admin/history/{user_id}", dependencies=[Depends(require_admin_token)])
async def admin_get_user_chat(user_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(ChatMessage)
        .where(ChatMessage.user_id == user_id)
        .order_by(ChatMessage.created_at.asc())
        .limit(200)
    )
    msgs = result.scalars().all()
    # Mark unread as read
    for m in msgs:
        if m.sender == "user" and not m.is_read:
            m.is_read = True
    await db.commit()
    return [_msg_dict(m) for m in msgs]


@router.post("/admin/send", dependencies=[Depends(require_admin_token)], response_model=MessageOut)
async def admin_send_message(
    payload: dict,
    db: AsyncSession = Depends(get_db),
):
    """REST fallback: admin sends message to user."""
    user_id = payload.get("user_id")
    text = (payload.get("message") or "").strip()
    if not user_id or not text:
        raise HTTPException(status_code=400, detail="user_id and message required")

    msg = ChatMessage(user_id=int(user_id), sender="admin", message=text)
    db.add(msg)
    await db.commit()
    await db.refresh(msg)
    await manager.send_to_user(int(user_id), {"type": "message", **_msg_dict(msg)})
    return MessageOut(message="Sent")
