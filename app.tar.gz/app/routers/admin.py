"""
app/routers/admin.py

Admin-only endpoints protected by ADMIN_SECRET_TOKEN header.
Also exposes /api/admin/stats and /api/admin/users for dashboard use.

All routes require the header:
    X-Admin-Token: <ADMIN_SECRET_TOKEN from .env>
"""
from datetime import datetime, timezone, UTC
from fastapi import APIRouter, Depends, Header, HTTPException, status
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.database import get_db
from app.models.endpoint import Endpoint
from app.models.submission import Submission
from app.models.user import User
from app.models.subscription import UserSubscription, SubscriptionPlan
from app.schemas.schemas import MessageOut

router = APIRouter(prefix="/api/admin", tags=["admin"])


async def require_admin_token(x_admin_token: str = Header(...)):
    """Dependency – validates the static admin secret passed as a header."""
    if x_admin_token != settings.ADMIN_SECRET_TOKEN:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Invalid admin token")


# ── Stats ─────────────────────────────────────────────────────────────────────

@router.get("/stats", dependencies=[Depends(require_admin_token)])
async def admin_stats(db: AsyncSession = Depends(get_db)):
    """Return platform-wide counts."""
    users_count = (await db.execute(select(func.count()).select_from(User))).scalar()
    ep_count    = (await db.execute(select(func.count()).select_from(Endpoint))).scalar()
    sub_count   = (await db.execute(select(func.count()).select_from(Submission))).scalar()
    delivered   = (await db.execute(
        select(func.count()).where(Submission.status == "delivered")
    )).scalar()

    return {
        "total_users":       users_count,
        "total_endpoints":   ep_count,
        "total_submissions": sub_count,
        "delivered":         delivered,
        "failed":            sub_count - delivered,
    }


# ── Users ─────────────────────────────────────────────────────────────────────

@router.get("/users", dependencies=[Depends(require_admin_token)])
async def list_all_users(db: AsyncSession = Depends(get_db)):
    """List every registered user with their subscription info."""
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    result = await db.execute(select(User).order_by(User.created_at.desc()))
    users = result.scalars().all()
    out = []
    for u in users:
        sub_res = await db.execute(select(UserSubscription).where(UserSubscription.user_id == u.id))
        sub = sub_res.scalar_one_or_none()
        plan_name = None
        days_left = 0
        if sub:
            plan_res = await db.execute(select(SubscriptionPlan).where(SubscriptionPlan.id == sub.plan_id))
            plan = plan_res.scalar_one_or_none()
            plan_name = plan.name if plan else "—"
            days_left = max(0, (sub.expires_at - now).days) if sub.expires_at > now else 0
        out.append({
            "id": u.id,
            "email": u.email,
            "full_name": u.full_name,
            "is_admin": u.is_admin,
            "is_active": u.is_active,
            "created_at": u.created_at.isoformat() if u.created_at else None,
            "subscription_plan": plan_name,
            "subscription_days_left": days_left,
        })
    return out


@router.patch("/users/{user_id}/deactivate",
              response_model=MessageOut,
              dependencies=[Depends(require_admin_token)])
async def deactivate_user(user_id: int, db: AsyncSession = Depends(get_db)):
    """Disable a user account (they can no longer log in)."""
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    if user.is_admin:
        raise HTTPException(status_code=400, detail="Cannot deactivate admin accounts")
    user.is_active = False
    await db.commit()
    return MessageOut(message=f"User {user.email} deactivated")


@router.patch("/users/{user_id}/activate",
              response_model=MessageOut,
              dependencies=[Depends(require_admin_token)])
async def activate_user(user_id: int, db: AsyncSession = Depends(get_db)):
    """Re-enable a previously deactivated user account."""
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    user.is_active = True
    await db.commit()
    return MessageOut(message=f"User {user.email} activated")


@router.delete("/users/{user_id}",
               response_model=MessageOut,
               dependencies=[Depends(require_admin_token)])
async def delete_user(user_id: int, db: AsyncSession = Depends(get_db)):
    """Permanently delete a user and all their data."""
    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    if user.is_admin:
        raise HTTPException(status_code=400, detail="Cannot delete admin accounts")
    await db.delete(user)
    await db.commit()
    return MessageOut(message=f"User {user.email} deleted")
