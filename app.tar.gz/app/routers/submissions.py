"""
app/routers/submissions.py

Two responsibilities:
  1. Public POST /f/{token}  – anyone can submit a form here
  2. Authenticated GET /api/submissions/{endpoint_id} – owner views history
"""
import json
from datetime import datetime, timezone

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Request, status
from fastapi.responses import JSONResponse, RedirectResponse
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.deps import get_current_user
from app.core.email import send_submission_email
from app.core.subscription_guard import get_active_subscription
from app.core.telegram import send_submission_telegram

from app.models.endpoint import Endpoint
from app.models.submission import Submission
from app.models.subscription import SubscriptionPlan
from app.models.user import User
from app.schemas.schemas import SubmissionOut

router = APIRouter(tags=["submissions"])


async def _deliver_email_and_telegram(
    *,
    to_email: str,
    telegram_bot_token: str | None,
    telegram_chat_id: str | None,
    endpoint_name: str,
    fields: dict,
    submitted_at: datetime,
    submission_id: int,
    db_session_factory,
) -> None:
    """Background task: send email + telegram, then update submission status."""
    email_success = await send_submission_email(to_email, endpoint_name, fields, submitted_at)
    telegram_success = False
    if telegram_bot_token and telegram_chat_id:
        telegram_success = await send_submission_telegram(
            bot_token=telegram_bot_token,
            chat_id=telegram_chat_id,
            endpoint_name=endpoint_name,
            fields=fields,
            submitted_at=submitted_at,
        )

    # Keep existing delivery semantics but prefer email outcome.
    # (If you want status based on Telegram only, change this logic.)
    delivered = email_success

    async with db_session_factory() as db:
        result = await db.execute(select(Submission).where(Submission.id == submission_id))
        sub = result.scalar_one_or_none()
        if sub:
            sub.status = "delivered" if delivered else "failed"
            await db.commit()



@router.post("/f/{token}")
async def intake_submission(
    token: str,
    request: Request,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db),
):
    """
    Public endpoint – accepts any form data (JSON or multipart/urlencoded) and
    forwards it to the endpoint owner's email.
    """
    # 1. Resolve endpoint
    result = await db.execute(select(Endpoint).where(Endpoint.token == token))
    ep = result.scalar_one_or_none()
    if not ep or not ep.is_active:
        raise HTTPException(status_code=404, detail="Endpoint not found or inactive")

    # 1b. Owner must have an active subscription (free trial or paid plan) to keep receiving submissions
    owner_sub = await get_active_subscription(ep.owner_id, db)
    if owner_sub is None:
        raise HTTPException(
            status_code=status.HTTP_402_PAYMENT_REQUIRED,
            detail="This endpoint's owner has no active subscription. Submissions are paused until they subscribe.",
        )

    # 4. Load owner's email & check plan for Telegram eligibility
    from app.models.user import User as UserModel  # avoid circular at module level
    user_result = await db.execute(select(UserModel).where(UserModel.id == ep.owner_id))
    owner = user_result.scalar_one()

    owner_telegram_token = owner.telegram_bot_token
    owner_telegram_chat_id = owner.telegram_chat_id
    plan_result = await db.execute(select(SubscriptionPlan).where(SubscriptionPlan.id == owner_sub.plan_id))
    plan = plan_result.scalar_one_or_none()
    if plan and plan.plan_type == "free_trial":
        owner_telegram_token = None
        owner_telegram_chat_id = None
    fields: dict = {}
    content_type = request.headers.get("content-type", "")

    if "application/json" in content_type:
        try:
            fields = await request.json()
        except Exception:
            raise HTTPException(status_code=400, detail="Invalid JSON body")
    elif "multipart/form-data" in content_type or "application/x-www-form-urlencoded" in content_type:
        form = await request.form()
        fields = dict(form)
    else:
        fields = dict(request.query_params)

    if not fields:
        raise HTTPException(status_code=422, detail="No fields found in submission")

    # Capture _redirect BEFORE removing it so it still works as a redirect target
    override_redirect = fields.pop("_redirect", None)

    # 3. Persist submission
    sender_ip = request.client.host if request.client else None
    now = datetime.now(timezone.utc)
    submission = Submission(
        endpoint_id=ep.id,
        fields_json=json.dumps(fields, default=str),
        sender_ip=sender_ip,
        status="pending",
        submitted_at=now,
    )
    db.add(submission)
    await db.commit()
    await db.refresh(submission)

    # 4. Load owner's email & enqueue email delivery in background
    from app.models.user import User as UserModel  # avoid circular at module level
    user_result = await db.execute(select(UserModel).where(UserModel.id == ep.owner_id))
    owner = user_result.scalar_one()

    from app.core.database import AsyncSessionLocal
    background_tasks.add_task(
        _deliver_email_and_telegram,
        to_email=owner.email,
        telegram_bot_token=owner_telegram_token,
        telegram_chat_id=owner_telegram_chat_id,
        endpoint_name=ep.name,
        fields=fields,
        submitted_at=now,
        submission_id=submission.id,
        db_session_factory=AsyncSessionLocal,
    )


    # 5. Respond – redirect if configured, else JSON
    redirect = override_redirect or ep.redirect_url
    if redirect:
        return RedirectResponse(url=redirect, status_code=302)

    return JSONResponse(
        status_code=200,
        content={"success": True, "message": "Submission received"},
    )


@router.get("/api/submissions/{endpoint_id}", response_model=list[SubmissionOut])
async def list_submissions(
    endpoint_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Return the 100 most recent submissions for an endpoint the current user owns."""
    # Verify ownership
    ep_result = await db.execute(
        select(Endpoint).where(Endpoint.id == endpoint_id, Endpoint.owner_id == current_user.id)
    )
    if not ep_result.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Endpoint not found")

    result = await db.execute(
        select(Submission)
        .where(Submission.endpoint_id == endpoint_id)
        .order_by(Submission.submitted_at.desc())
        .limit(100)
    )
    return result.scalars().all()
