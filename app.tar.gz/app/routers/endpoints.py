"""
app/routers/endpoints.py
CRUD operations for user-owned forwarding endpoints.
"""
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.deps import get_current_user
from app.core.subscription_guard import require_active_subscription
from app.models.endpoint import Endpoint
from app.models.submission import Submission
from app.models.subscription import SubscriptionPlan
from app.models.user import User
from app.schemas.schemas import EndpointCreate, EndpointOut, EndpointUpdate, MessageOut

router = APIRouter(prefix="/api/endpoints", tags=["endpoints"])


async def _get_endpoint_or_404(endpoint_id: int, user: User, db: AsyncSession) -> Endpoint:
    result = await db.execute(
        select(Endpoint).where(Endpoint.id == endpoint_id, Endpoint.owner_id == user.id)
    )
    ep = result.scalar_one_or_none()
    if not ep:
        raise HTTPException(status_code=404, detail="Endpoint not found")
    return ep


@router.post("", response_model=EndpointOut, status_code=status.HTTP_201_CREATED)
async def create_endpoint(
    payload: EndpointCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
    _sub=Depends(require_active_subscription),
):
    existing_count = (await db.execute(
        select(func.count()).where(
            Endpoint.owner_id == current_user.id,
            Endpoint.is_active == True,
        )
    )).scalar() or 0

    plan = await db.get(SubscriptionPlan, _sub.plan_id)
    if plan and existing_count >= plan.max_endpoints:
        raise HTTPException(
            status_code=status.HTTP_402_PAYMENT_REQUIRED,
            detail=f"Plan limit reached ({plan.max_endpoints} endpoints). Upgrade your plan to create more.",
        )

    ep = Endpoint(owner_id=current_user.id, **payload.model_dump(exclude_none=True))
    db.add(ep)
    await db.commit()
    await db.refresh(ep)
    return EndpointOut(**ep.__dict__, submission_count=0)


@router.get("", response_model=list[EndpointOut])
async def list_endpoints(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(select(Endpoint).where(Endpoint.owner_id == current_user.id))
    endpoints = result.scalars().all()

    out = []
    for ep in endpoints:
        count_result = await db.execute(
            select(func.count()).where(Submission.endpoint_id == ep.id)
        )
        out.append(EndpointOut(**ep.__dict__, submission_count=count_result.scalar() or 0))
    return out


@router.get("/{endpoint_id}", response_model=EndpointOut)
async def get_endpoint(
    endpoint_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    ep = await _get_endpoint_or_404(endpoint_id, current_user, db)
    count_result = await db.execute(
        select(func.count()).where(Submission.endpoint_id == ep.id)
    )
    return EndpointOut(**ep.__dict__, submission_count=count_result.scalar() or 0)


@router.patch("/{endpoint_id}", response_model=EndpointOut)
async def update_endpoint(
    endpoint_id: int,
    payload: EndpointUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    ep = await _get_endpoint_or_404(endpoint_id, current_user, db)
    for field, value in payload.model_dump(exclude_none=True).items():
        setattr(ep, field, value)
    await db.commit()
    await db.refresh(ep)
    count_result = await db.execute(
        select(func.count()).where(Submission.endpoint_id == ep.id)
    )
    return EndpointOut(**ep.__dict__, submission_count=count_result.scalar() or 0)


@router.delete("/{endpoint_id}", response_model=MessageOut)
async def delete_endpoint(
    endpoint_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    ep = await _get_endpoint_or_404(endpoint_id, current_user, db)
    await db.delete(ep)
    await db.commit()
    return MessageOut(message="Endpoint deleted")
