"""
app/routers/subscriptions.py
Public + user subscription endpoints.
"""
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.deps import get_current_user
from app.models.subscription import SubscriptionPayment, SubscriptionPlan, UserSubscription, UsdtWallet
from app.models.user import User
from app.schemas.schemas import MessageOut, PaymentOut, PaymentSubmit, PlanOut, SubscriptionOut, WalletOut

router = APIRouter(prefix="/api/subscriptions", tags=["subscriptions"])


def _ensure_utc(value: datetime | None) -> datetime | None:
    if value is None:
        return None
    if value.tzinfo is None or value.tzinfo.utcoffset(value) is None:
        return value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc)


# ── Public: list active plans & wallets ───────────────────────────────────────

@router.get("/plans", response_model=list[PlanOut])
async def list_plans(db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(SubscriptionPlan).where(SubscriptionPlan.is_active == True).order_by(SubscriptionPlan.price_usdt)
    )
    return result.scalars().all()


@router.get("/wallets", response_model=list[WalletOut])
async def list_wallets(db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(UsdtWallet).where(UsdtWallet.is_active == True)
    )
    return result.scalars().all()


# ── User: current subscription status ────────────────────────────────────────

@router.get("/my", response_model=dict)
async def my_subscription(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(UserSubscription).where(UserSubscription.user_id == current_user.id)
    )
    sub = result.scalar_one_or_none()
    now = datetime.now(timezone.utc)

    if not sub:
        return {"status": "none", "subscription": None, "plan": None}

    # Auto-expire (defensive: legacy DB rows might have NULL/invalid expires_at)
    effective_expires_at = _ensure_utc(sub.expires_at)
    if effective_expires_at is None:
        sub.is_active = False
        await db.commit()
        effective_expires_at = now
    else:
        if effective_expires_at < now:
            sub.is_active = False
            await db.commit()
            effective_expires_at = _ensure_utc(sub.expires_at) or now


    plan_res = await db.execute(select(SubscriptionPlan).where(SubscriptionPlan.id == sub.plan_id))

    plan = plan_res.scalar_one_or_none()
    started_at = _ensure_utc(sub.started_at)
    is_active = bool(sub.is_active and effective_expires_at > now)

    return {
        "status": "active" if is_active else "expired",
        "subscription": {
            "id": sub.id,
            "plan_id": sub.plan_id,
            "started_at": started_at.isoformat() if started_at else None,
            "expires_at": effective_expires_at.isoformat(),
            "is_active": is_active,
            "days_left": max(0, (effective_expires_at - now).days),

        },
        "plan": {
            "id": plan.id,
            "name": plan.name,
            "plan_type": plan.plan_type,
            "price_usdt": float(plan.price_usdt),
            "max_endpoints": plan.max_endpoints,
            "max_submissions_per_day": plan.max_submissions_per_day,
            "features": plan.features,
        } if plan else None,
    }


# ── User: claim free trial ────────────────────────────────────────────────────

@router.post("/free-trial", response_model=MessageOut)
async def claim_free_trial(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    # Check if user already has / had a subscription
    existing = await db.execute(
        select(UserSubscription).where(UserSubscription.user_id == current_user.id)
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="You have already used a subscription or free trial.")

    # Find an active free trial plan
    plan_res = await db.execute(
        select(SubscriptionPlan).where(
            SubscriptionPlan.plan_type == "free_trial",
            SubscriptionPlan.is_active == True,
        )
    )
    plan = plan_res.scalars().first()
    if not plan:
        raise HTTPException(status_code=404, detail="No free trial plan is available right now.")

    now = datetime.now(timezone.utc)
    sub = UserSubscription(
        user_id=current_user.id,
        plan_id=plan.id,
        started_at=now,
        expires_at=now + timedelta(days=plan.duration_days),
        is_active=True,
    )
    db.add(sub)
    await db.commit()
    return MessageOut(message=f"Free trial activated! You have {plan.duration_days} days of access.")


# ── User: submit payment proof ─────────────────────────────────────────────────

@router.post("/pay", response_model=MessageOut)
async def submit_payment(
    payload: PaymentSubmit,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    # Validate plan
    plan_res = await db.execute(
        select(SubscriptionPlan).where(
            SubscriptionPlan.id == payload.plan_id,
            SubscriptionPlan.is_active == True,
        )
    )
    plan = plan_res.scalar_one_or_none()
    if not plan:
        raise HTTPException(status_code=404, detail="Plan not found.")
    if plan.plan_type == "free_trial":
        raise HTTPException(status_code=400, detail="Use the free trial endpoint instead.")

    # Validate wallet
    wallet_res = await db.execute(
        select(UsdtWallet).where(UsdtWallet.id == payload.wallet_id, UsdtWallet.is_active == True)
    )
    if not wallet_res.scalar_one_or_none():
        raise HTTPException(status_code=404, detail="Wallet not found.")

    # Check for duplicate pending tx_hash
    dup = await db.execute(
        select(SubscriptionPayment).where(SubscriptionPayment.tx_hash == payload.tx_hash)
    )
    if dup.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="This transaction hash has already been submitted.")

    payment = SubscriptionPayment(
        user_id=current_user.id,
        plan_id=payload.plan_id,
        wallet_id=payload.wallet_id,
        amount_usdt=float(plan.price_usdt),
        tx_hash=payload.tx_hash,
        status="pending",
    )
    db.add(payment)
    await db.commit()
    return MessageOut(message="Payment submitted! Your subscription will be activated once the admin verifies your transaction.")


# ── User: payment history ──────────────────────────────────────────────────────

@router.get("/my/payments", response_model=list[PaymentOut])
async def my_payments(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    result = await db.execute(
        select(SubscriptionPayment)
        .where(SubscriptionPayment.user_id == current_user.id)
        .order_by(SubscriptionPayment.submitted_at.desc())
    )
    return result.scalars().all()
