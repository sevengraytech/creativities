"""
app/routers/auth.py
User registration, login, logout, profile, password reset.
"""
import secrets
from datetime import timedelta, datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Response, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.deps import get_current_user
from app.core.security import create_access_token, hash_password, verify_password
from app.core.config import settings
from app.models.user import User
from app.schemas.schemas import (
    MessageOut, TelegramSettingsIn, TelegramSettingsOut,
    Token, UserLogin, UserOut, UserRegister,
    PasswordResetRequest, PasswordResetConfirm,
)

router = APIRouter(prefix="/api/auth", tags=["auth"])

MAX_FAILED_ATTEMPTS = 5
LOCKOUT_MINUTES = 15


@router.post("/register", response_model=UserOut, status_code=status.HTTP_201_CREATED)
async def register(payload: UserRegister, db: AsyncSession = Depends(get_db)):
    """Create a new user account."""
    result = await db.execute(select(User).where(User.email == payload.email))
    if result.scalar_one_or_none():
        raise HTTPException(status_code=400, detail="Email already registered")

    user = User(
        email=payload.email,
        hashed_password=hash_password(payload.password),
        full_name=payload.full_name,
        telegram_bot_token=getattr(payload, "telegram_bot_token", None),
        telegram_chat_id=getattr(payload, "telegram_chat_id", None),
    )

    db.add(user)
    await db.commit()
    await db.refresh(user)
    return user


@router.post("/login", response_model=Token)
async def login(payload: UserLogin, response: Response, db: AsyncSession = Depends(get_db)):
    """Authenticate and return a JWT; also sets an HttpOnly cookie."""
    result = await db.execute(select(User).where(User.email == payload.email))
    user = result.scalar_one_or_none()

    # Generic error for unknown email (don't leak existence)
    if not user:
        raise HTTPException(status_code=401, detail="Incorrect email or password")

    # Check lockout
    now = datetime.now(timezone.utc)
    if user.locked_until and user.locked_until > now:
        remaining = int((user.locked_until - now).total_seconds() / 60) + 1
        raise HTTPException(
            status_code=429,
            detail=f"Account temporarily locked due to too many failed attempts. Try again in {remaining} minute(s)."
        )

    if not verify_password(payload.password, user.hashed_password):
        # Increment failed attempts
        user.failed_login_attempts = (user.failed_login_attempts or 0) + 1
        attempts_left = MAX_FAILED_ATTEMPTS - user.failed_login_attempts

        if user.failed_login_attempts >= MAX_FAILED_ATTEMPTS:
            user.locked_until = datetime.now(timezone.utc) + timedelta(minutes=LOCKOUT_MINUTES)
            await db.commit()
            raise HTTPException(
                status_code=429,
                detail=f"Too many failed attempts. Account locked for {LOCKOUT_MINUTES} minutes."
            )

        await db.commit()
        if attempts_left <= 2:
            raise HTTPException(
                status_code=401,
                detail=f"Incorrect email or password. Warning: {attempts_left} attempt(s) left before lockout."
            )
        raise HTTPException(
            status_code=401,
            detail=f"Incorrect email or password. {attempts_left} attempt(s) remaining before lockout."
        )

    if not user.is_active:
        raise HTTPException(status_code=403, detail="Account is deactivated. Contact support.")

    # Reset failed attempts on success
    user.failed_login_attempts = 0
    user.locked_until = None
    await db.commit()

    token = create_access_token(str(user.id))
    response.set_cookie(
        key="access_token",
        value=token,
        httponly=True,
        max_age=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        samesite="lax",
    )
    return Token(access_token=token)


@router.post("/logout", response_model=MessageOut)
async def logout(response: Response):
    response.delete_cookie("access_token")
    return MessageOut(message="Logged out")


@router.get("/me", response_model=UserOut)
async def me(current_user: User = Depends(get_current_user)):
    return current_user


@router.get("/telegram-settings", response_model=TelegramSettingsOut)
async def get_telegram_settings(current_user: User = Depends(get_current_user)):
    return TelegramSettingsOut(
        telegram_bot_token=current_user.telegram_bot_token,
        telegram_chat_id=current_user.telegram_chat_id,
    )


@router.patch("/telegram-settings", response_model=TelegramSettingsOut)
async def patch_telegram_settings(
    payload: TelegramSettingsIn,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    bot_token = payload.telegram_bot_token
    chat_id = payload.telegram_chat_id
    if bot_token is not None and not bot_token.strip():
        bot_token = None
    if chat_id is not None and not chat_id.strip():
        chat_id = None

    current_user.telegram_bot_token = bot_token
    current_user.telegram_chat_id = chat_id
    db.add(current_user)
    await db.commit()
    await db.refresh(current_user)

    return TelegramSettingsOut(
        telegram_bot_token=current_user.telegram_bot_token,
        telegram_chat_id=current_user.telegram_chat_id,
    )


# ── Password Reset ────────────────────────────────────────────────────────────

@router.post("/forgot-password", response_model=MessageOut)
async def forgot_password(payload: PasswordResetRequest, db: AsyncSession = Depends(get_db)):
    """Send a password reset link to the user's email."""
    result = await db.execute(select(User).where(User.email == payload.email))
    user = result.scalar_one_or_none()

    # Always return success to prevent email enumeration
    if not user or not user.is_active:
        return MessageOut(message="If that email exists, a reset link has been sent.")

    token = secrets.token_urlsafe(32)
    user.reset_token = token
    user.reset_token_expires = datetime.now(timezone.utc) + timedelta(hours=1)
    await db.commit()

    reset_link = f"{settings.BASE_URL}/reset-password?token={token}"
    await _send_reset_email(user.email, reset_link)

    return MessageOut(message="If that email exists, a reset link has been sent.")


@router.post("/reset-password", response_model=MessageOut)
async def reset_password(payload: PasswordResetConfirm, db: AsyncSession = Depends(get_db)):
    """Verify token and set new password."""
    result = await db.execute(select(User).where(User.reset_token == payload.token))
    user = result.scalar_one_or_none()

    if not user:
        raise HTTPException(status_code=400, detail="Invalid or expired reset token.")

    now = datetime.now(timezone.utc)
    if not user.reset_token_expires or user.reset_token_expires < now:
        raise HTTPException(status_code=400, detail="Reset token has expired. Please request a new one.")

    user.hashed_password = hash_password(payload.new_password)
    user.reset_token = None
    user.reset_token_expires = None
    user.failed_login_attempts = 0
    user.locked_until = None
    await db.commit()

    return MessageOut(message="Password reset successfully. You can now log in.")


async def _send_reset_email(to_email: str, reset_link: str):
    """Send the password reset email."""
    from email.mime.multipart import MIMEMultipart
    from email.mime.text import MIMEText
    import aiosmtplib
    import logging

    logger = logging.getLogger(__name__)

    if not settings.SMTP_USERNAME:
        logger.warning("SMTP not configured – reset link: %s", reset_link)
        return

    html = f"""
<!DOCTYPE html>
<html>
<body style="font-family:'Segoe UI',Arial,sans-serif;background:#f0f4f8;margin:0;padding:32px">
  <table width="600" style="background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 2px 12px rgba(0,0,0,.08);margin:0 auto">
    <tr><td style="background:linear-gradient(135deg,#0ea5e9,#6366f1);padding:28px 32px">
      <div style="color:#fff;font-size:22px;font-weight:700">Reset Your Password</div>
      <div style="color:rgba(255,255,255,.8);font-size:14px;margin-top:4px">FormRelay</div>
    </td></tr>
    <tr><td style="padding:32px">
      <p style="color:#374151;margin-bottom:24px">You requested a password reset. Click the button below to set a new password. This link expires in 1 hour.</p>
      <a href="{reset_link}" style="display:inline-block;background:#3b82f6;color:#fff;padding:12px 28px;border-radius:8px;text-decoration:none;font-weight:600">Reset Password</a>
      <p style="color:#9ca3af;font-size:12px;margin-top:24px">If you didn't request this, ignore this email. Your password won't change.</p>
    </td></tr>
  </table>
</body>
</html>"""

    msg = MIMEMultipart("alternative")
    msg["Subject"] = "[FormRelay] Password Reset Request"
    msg["From"] = f"{settings.SMTP_FROM_NAME} <{settings.SMTP_FROM_EMAIL}>"
    msg["To"] = to_email
    msg.attach(MIMEText(f"Reset your password: {reset_link}", "plain"))
    msg.attach(MIMEText(html, "html"))

    try:
        await aiosmtplib.send(
            msg,
            hostname=settings.SMTP_HOST,
            port=settings.SMTP_PORT,
            username=settings.SMTP_USERNAME,
            password=settings.SMTP_PASSWORD,
            start_tls=True,
            timeout=15,
        )
    except Exception as exc:
        logger.error("Failed to send reset email: %s", exc)
