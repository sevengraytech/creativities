"""app/models/subscription.py - Subscription plans, USDT wallets, and user subscriptions."""
from datetime import datetime, timezone
from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, Numeric, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship
from app.core.database import Base


class SubscriptionPlan(Base):
    """Admin-defined plans (Free Trial, Monthly, Yearly)."""
    __tablename__ = "subscription_plans"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(64), nullable=False)          # e.g. "Pro Monthly"
    plan_type: Mapped[str] = mapped_column(String(16), nullable=False)     # free_trial | monthly | yearly
    price_usdt: Mapped[float] = mapped_column(Numeric(12, 2), nullable=False, default=0)
    duration_days: Mapped[int] = mapped_column(Integer, nullable=False)    # 14, 30, 365
    max_endpoints: Mapped[int] = mapped_column(Integer, default=5)
    max_submissions_per_day: Mapped[int] = mapped_column(Integer, default=500)
    features: Mapped[str | None] = mapped_column(Text, nullable=True)      # JSON array of feature strings
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )

    payments: Mapped[list["SubscriptionPayment"]] = relationship(
        "SubscriptionPayment", back_populates="plan"
    )


class UsdtWallet(Base):
    """Admin-configured USDT wallet addresses shown to users for payment."""
    __tablename__ = "usdt_wallets"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    label: Mapped[str] = mapped_column(String(64), nullable=False)          # e.g. "TRC20 (TRON)"
    network: Mapped[str] = mapped_column(String(32), nullable=False)        # TRC20 | ERC20 | BEP20
    address: Mapped[str] = mapped_column(String(256), nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )


class SubscriptionPayment(Base):
    """A payment submission by a user, pending admin approval."""
    __tablename__ = "subscription_payments"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    user_id: Mapped[int] = mapped_column(Integer, ForeignKey("users.id", ondelete="CASCADE"), index=True)
    plan_id: Mapped[int] = mapped_column(Integer, ForeignKey("subscription_plans.id"), index=True)
    wallet_id: Mapped[int | None] = mapped_column(Integer, ForeignKey("usdt_wallets.id"), nullable=True)
    amount_usdt: Mapped[float] = mapped_column(Numeric(12, 2), nullable=False)
    tx_hash: Mapped[str | None] = mapped_column(String(256), nullable=True)  # transaction hash from user
    status: Mapped[str] = mapped_column(String(16), default="pending")        # pending | approved | rejected
    admin_note: Mapped[str | None] = mapped_column(String(512), nullable=True)
    submitted_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )
    reviewed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    user: Mapped["User"] = relationship("User", foreign_keys=[user_id])  # noqa: F821
    plan: Mapped["SubscriptionPlan"] = relationship("SubscriptionPlan", back_populates="payments")
    wallet: Mapped["UsdtWallet"] = relationship("UsdtWallet")


class UserSubscription(Base):
    """Active subscription record for a user."""
    __tablename__ = "user_subscriptions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    user_id: Mapped[int] = mapped_column(Integer, ForeignKey("users.id", ondelete="CASCADE"), unique=True, index=True)
    plan_id: Mapped[int] = mapped_column(Integer, ForeignKey("subscription_plans.id"))
    payment_id: Mapped[int | None] = mapped_column(Integer, ForeignKey("subscription_payments.id"), nullable=True)
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)

    user: Mapped["User"] = relationship("User")  # noqa: F821
    plan: Mapped["SubscriptionPlan"] = relationship("SubscriptionPlan")
    payment: Mapped["SubscriptionPayment"] = relationship("SubscriptionPayment")
